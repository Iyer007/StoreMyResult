<footer style="background-color:black; position:fixed; bottom:0px; height:5vh; width:100%;">
    <p style="color:white;font-weight:bold;font-size:20px; text-align:Center; padding-top:7px;" >Developed by Abhinay, Karthik, Farhan and Manish</p>
</footer>
