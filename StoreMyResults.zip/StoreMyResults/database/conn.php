<?php
$conn=new mysqli("localhost","root","","results");
if(!$conn){
    die("Sorry There is a Problem Please Try Again...");
}
?>